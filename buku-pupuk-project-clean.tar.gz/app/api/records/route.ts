import {env} from 'cloudflare:workers';
function db(){if(!env.DB)throw Error('Penyimpanan belum tersedia');return env.DB;}
export async function GET(){try {const rows=await db().prepare('SELECT * FROM records ORDER BY date DESC,rowid DESC').all();return Response.json(rows.results);}catch(e){console.error(e);return Response.json({error:'Catatan belum dapat dimuat. Coba lagi.'},{status:503});}}
export async function POST(req:Request){try{
const x=await req.json() as {type:string;date:string;name:string;product:string;qty:number;amount:number;paid:number;ref:string;note:string};const types=['withdraw','purchase','expense','sale','pay','collect'];
if(!types.includes(x.type)||!/^\d{4}-\d{2}-\d{2}$/.test(x.date)||!x.name?.trim()||!Number.isSafeInteger(x.amount)||x.amount<=0||!Number.isSafeInteger(x.paid)||x.paid<0||x.paid>x.amount||!Number.isFinite(x.qty)||x.qty<0||x.name.length>200||(x.note||'').length>1000)return Response.json({error:'Periksa tanggal, nama dan nominal.'},{status:400});
if(['sale','purchase'].includes(x.type)&&(!x.product?.trim()||x.qty<=0))return Response.json({error:'Isi jenis pupuk dan jumlah kilogram.'},{status:400});
const vals=[crypto.randomUUID(),x.type,x.date,x.name.trim(),x.product||'',x.qty,x.amount,x.paid,x.ref||'',x.note||''];let sql='INSERT INTO records (id,type,date,name,product,qty,amount,paid,ref,note) SELECT ?,?,?,?,?,?,?,?,?,?';
if(x.type==='sale'){sql+=" WHERE COALESCE((SELECT SUM(CASE WHEN type='purchase' THEN qty WHEN type='sale' THEN -qty ELSE 0 END) FROM records WHERE product=?),0)>=?";vals.push(x.product,x.qty);}
if(['pay','collect'].includes(x.type)){sql+=" WHERE EXISTS (SELECT 1 FROM records r WHERE r.id=? AND r.type=? AND r.amount-r.paid-COALESCE((SELECT SUM(p.amount) FROM records p WHERE p.ref=r.id AND p.type=?),0)>=?)";vals.push(x.ref,x.type==='pay'?'purchase':'sale',x.type,x.amount);}
const result=await db().prepare(sql).bind(...vals).run();if(!result.meta.changes)return Response.json({error:'Stok tidak mencukupi atau pembayaran melebihi sisa tagihan.'},{status:409});return Response.json({ok:true});
}catch(e){console.error(e);return Response.json({error:'Catatan gagal disimpan. Isian Anda tetap tersedia.'},{status:503});}}

export async function PATCH(req:Request){try{
if(req.headers.get('origin')!==new URL(req.url).origin)return Response.json({error:'Buka pengeditan melalui aplikasi.'},{status:403});
const x=await req.json() as any;
if(!x||typeof x.id!=='string'||typeof x.type!=='string'||!['withdraw','purchase','expense','sale','pay','collect'].includes(x.type)||typeof x.date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(x.date)||Number.isNaN(Date.parse(x.date))||typeof x.name!=='string'||!x.name.trim()||x.name.length>200||typeof x.product!=='string'||x.product.length>200||typeof x.ref!=='string'||x.ref.length>100||typeof x.note!=='string'||x.note.length>1000||!Number.isSafeInteger(x.amount)||x.amount<=0||!Number.isSafeInteger(x.paid)||x.paid<0||x.paid>x.amount||!Number.isFinite(x.qty)||x.qty<0)return Response.json({error:'Periksa tanggal, nama, jumlah dan nominal.'},{status:400});
if(['sale','purchase'].includes(x.type)?!x.product.trim()||x.qty<=0:x.qty!==0||x.paid!==0)return Response.json({error:'Jumlah pupuk atau pembayaran tidak valid.'},{status:400});
const old=await db().prepare('SELECT * FROM records WHERE id=?').bind(x.id).first<any>();
if(!old)return Response.json({error:'Transaksi tidak ditemukan. Muat ulang catatan.'},{status:404});
if(old.type!==x.type)return Response.json({error:'Jenis transaksi tidak boleh diganti melalui pengeditan.'},{status:400});
const fields=['date','name','product','qty','amount','paid','ref','note'];
if(!x.original||fields.some(k=>x.original[k]!==old[k]))return Response.json({error:'Transaksi telah berubah sejak form dibuka. Tutup form dan muat ulang sebelum mengedit kembali.'},{status:409});
const {editRecordSql}=await import('@/lib/edit-record');
const values=[x.id,x.id,x.type,x.date,x.name.trim(),x.product,x.qty,x.amount,x.paid,x.ref,x.note,x.date,x.name.trim(),x.product,x.qty,x.amount,x.paid,x.ref,x.note,x.id,x.type,...fields.map(k=>old[k])];
const result=await db().prepare(editRecordSql).bind(...values).run();
if(!result.meta.changes)return Response.json({error:'Perubahan ditolak karena stok akan negatif, pembayaran melebihi tagihan, atau transaksi berubah. Periksa isian atau muat ulang catatan.'},{status:409});
return Response.json({ok:true});
}catch(e){console.error(e);return Response.json({error:'Perubahan belum dapat disimpan. Isian Anda tetap tersedia.'},{status:503});}}
