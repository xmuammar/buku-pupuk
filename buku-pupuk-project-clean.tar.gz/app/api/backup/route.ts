import {env} from 'cloudflare:workers';
import {reportData,type RecordRow} from '@/lib/report-data';
const headers={'Cache-Control':'private, no-store'};
export async function GET(){try{if(!env.DB)throw Error('DB missing');const data=await env.DB.prepare('SELECT * FROM records ORDER BY rowid').all<RecordRow>();return Response.json({app:'buku-pupuk',version:1,createdAt:new Date().toISOString(),recordCount:data.results.length,records:data.results},{headers:{...headers,'Content-Disposition':`attachment; filename="buku-pupuk-${new Date().toISOString().slice(0,10)}.json"`}});}catch(e){console.error(e);return Response.json({error:'Cadangan belum dapat dibuat. Coba lagi.'},{status:503,headers});}}
export async function POST(req:Request){
try{
if(req.headers.get('origin')!==new URL(req.url).origin)return Response.json({error:'Buka pemulihan melalui aplikasi.'},{status:403,headers});
const text=await req.text();if(text.length>5_000_000)return Response.json({error:'Ukuran cadangan melebihi 5 MB.'},{status:413,headers});
const data=JSON.parse(text);
if(data.app!=='buku-pupuk'||data.version!==1||!Array.isArray(data.records)||data.recordCount!==data.records.length||data.records.length>10000)return Response.json({error:'File bukan cadangan Buku Pupuk yang valid.'},{status:400,headers});
const fields=['id','type','date','name','product','qty','amount','paid','ref','note'];const rows:RecordRow[]=data.records;const seen=new Set<string>();
for(const r of rows){if(!r||typeof r.id!=='string'||!r.id||r.id.length>100||seen.has(r.id)||!['withdraw','purchase','expense','sale','pay','collect'].includes(r.type)||typeof r.date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(r.date)||Number.isNaN(Date.parse(r.date))||typeof r.name!=='string'||!r.name.trim()||r.name.length>200||typeof r.product!=='string'||r.product.length>200||typeof r.note!=='string'||r.note.length>1000||typeof r.ref!=='string'||r.ref.length>100||!Number.isSafeInteger(r.amount)||r.amount<=0||!Number.isSafeInteger(r.paid)||r.paid<0||r.paid>r.amount||!Number.isFinite(r.qty)||r.qty<0)return Response.json({error:'Cadangan berisi transaksi yang tidak valid atau ID berulang.'},{status:400,headers});
if(['purchase','sale'].includes(r.type)?(!r.product.trim()||r.qty<=0):r.qty!==0||r.paid!==0)return Response.json({error:'Jumlah atau pembayaran transaksi dalam cadangan tidak valid.'},{status:400,headers});seen.add(r.id);}
if(!env.DB)throw Error('DB missing');const existing=(await env.DB.prepare('SELECT * FROM records').all<RecordRow>()).results;const map=new Map(existing.map(r=>[r.id,r]));
for(const r of rows){const old=map.get(r.id);if(old&&fields.some(k=>(old as any)[k]!== (r as any)[k]))return Response.json({error:'Ada ID transaksi dengan isi berbeda. Pemulihan dibatalkan agar data tidak tertimpa.'},{status:409,headers});}
const merged=[...existing,...rows.filter(r=>!map.has(r.id))],byId=new Map(merged.map(r=>[r.id,r]));
for(const r of merged.filter(r=>r.type==='pay'||r.type==='collect')){const target=byId.get(r.ref);if(!target||target.type!==(r.type==='pay'?'purchase':'sale'))return Response.json({error:'Referensi pembayaran dalam cadangan tidak lengkap.'},{status:400,headers});}
const totals=reportData(merged);if(totals.stock.some(r=>r.balance<-.000001)||[...totals.debts,...totals.credits].some(r=>r.remaining<0))return Response.json({error:'Cadangan menghasilkan stok negatif atau pembayaran berlebih. Tidak ada data yang ditambahkan.'},{status:400,headers});
const clean=rows.map(r=>Object.fromEntries(fields.map(k=>[k,(r as any)[k]])));
const result=await env.DB.prepare("INSERT INTO records (id,type,date,name,product,qty,amount,paid,ref,note) SELECT json_extract(value,'$.id'),json_extract(value,'$.type'),json_extract(value,'$.date'),json_extract(value,'$.name'),json_extract(value,'$.product'),json_extract(value,'$.qty'),json_extract(value,'$.amount'),json_extract(value,'$.paid'),json_extract(value,'$.ref'),json_extract(value,'$.note') FROM json_each(?) WHERE true ON CONFLICT(id) DO NOTHING").bind(JSON.stringify(clean)).run();
return Response.json({ok:true,added:result.meta.changes,skipped:rows.length-result.meta.changes},{headers});
}catch(e){console.error(e);return Response.json({error:'File gagal dipulihkan. Periksa format cadangan dan coba lagi.'},{status:400,headers});}}
